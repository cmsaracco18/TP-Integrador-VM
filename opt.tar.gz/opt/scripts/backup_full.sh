#!/bin/bash

if [[ "$1" == "-help" ]]; then
	echo "Uso: $0 <origen> <destino>"
	echo "Ejemplo: $0 /var/log /backup_dir"
	exit 0
fi

ORIGEN=$1
DESTINO=$2

if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
	echo "Error: Debe indicar origen y destino."
	echo "Use -help para mas informacion."
	exit 1
fi

if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: Directorio de origen no existe."
	exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
	echo "Error: Directorio de destino no existe."
	exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

tar -czf "$ARCHIVO" "$ORIGEN"

echo "Backup generado: $ARCHIVO"
